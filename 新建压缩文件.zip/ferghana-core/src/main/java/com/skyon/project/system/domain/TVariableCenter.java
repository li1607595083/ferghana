package com.skyon.project.system.domain;

import com.skyon.framework.web.domain.BaseEntity;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.util.Date;

/**
 * 变量管理中心对象 t_variable_center
 * 
 * @author ruoyi
 * @date 2020-08-06
 */
public class TVariableCenter extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** $column.columnComment */
    private Long variableId;

    /** 变量名称 */
    private String variableName;

    /** 变量英文名称 */
    private String variableNameEn;

    /** 变量类型 01基础变量 02 派生变量 */
    private String variableType;

    /** 变量备注 */
    private String description;

    /** 模板类型 01 普通查询 02 统计查询 03 数据加工 */
    private String variableModelType;

    /** 普通-数据源 */
    private String sourceDataTable;

    // 统计-分组
    private String statisticsGroup;
    // 统计-计算模板
    private String statisticsCountModel;
    // 统计模式 01 滚动窗口  02 滑动窗口
    private String statisticsModel;
    // 统计时间
    private String statisticsNum;
    // 统计周期  01秒 02分 03小时 04天 05周 06月 07年
    private String statisticsCycle;
    // 统计条件选项
    private String statisticsConditionOption;
    // 统计条件集合
    private String statisticsConditions;
    // 加工数据模板
    private String processModel;
    // 加工输入数据
    private String processInputParams;

    /** 普通-数据维表 */
    private String dimensionTable;

    /** 修改时间 */
    private Date modifyTime;

    public void setVariableId(Long variableId) 
    {
        this.variableId = variableId;
    }

    public Long getVariableId() 
    {
        return variableId;
    }
    public void setVariableName(String variableName) 
    {
        this.variableName = variableName;
    }

    public String getVariableName() 
    {
        return variableName;
    }
    public void setVariableNameEn(String variableNameEn) 
    {
        this.variableNameEn = variableNameEn;
    }

    public String getVariableNameEn() 
    {
        return variableNameEn;
    }
    public void setVariableType(String variableType) 
    {
        this.variableType = variableType;
    }

    public String getVariableType() 
    {
        return variableType;
    }
    public void setDescription(String description) 
    {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }

    public String getVariableModelType() {
        return variableModelType;
    }

    public void setVariableModelType(String variableModelType) {
        this.variableModelType = variableModelType;
    }

    public void setSourceDataTable(String sourceDataTable) {
        this.sourceDataTable = sourceDataTable;
    }

    public String getSourceDataTable()
    {
        return sourceDataTable;
    }
    public void setDimensionTable(String dimensionTable) 
    {
        this.dimensionTable = dimensionTable;
    }

    public String getDimensionTable() 
    {
        return dimensionTable;
    }
    public void setModifyTime(Date modifyTime) 
    {
        this.modifyTime = modifyTime;
    }

    public Date getModifyTime() 
    {
        return modifyTime;
    }


    public String getStatisticsGroup() {
        return statisticsGroup;
    }

    public void setStatisticsGroup(String statisticsGroup) {
        this.statisticsGroup = statisticsGroup;
    }

    public String getStatisticsCountModel() {
        return statisticsCountModel;
    }

    public void setStatisticsCountModel(String statisticsCountModel) {
        this.statisticsCountModel = statisticsCountModel;
    }

    public String getStatisticsModel() {
        return statisticsModel;
    }

    public void setStatisticsModel(String statisticsModel) {
        this.statisticsModel = statisticsModel;
    }

    public String getStatisticsNum() {
        return statisticsNum;
    }

    public void setStatisticsNum(String statisticsNum) {
        this.statisticsNum = statisticsNum;
    }

    public String getStatisticsCycle() {
        return statisticsCycle;
    }

    public void setStatisticsCycle(String statisticsCycle) {
        this.statisticsCycle = statisticsCycle;
    }

    public String getStatisticsConditionOption() {
        return statisticsConditionOption;
    }

    public void setStatisticsConditionOption(String statisticsConditionOption) {
        this.statisticsConditionOption = statisticsConditionOption;
    }

    public String getStatisticsConditions() {
        return statisticsConditions;
    }

    public void setStatisticsConditions(String statisticsConditions) {
        this.statisticsConditions = statisticsConditions;
    }

    public String getProcessModel() {
        return processModel;
    }

    public void setProcessModel(String processModel) {
        this.processModel = processModel;
    }

    public String getProcessInputParams() {
        return processInputParams;
    }

    public void setProcessInputParams(String processInputParams) {
        this.processInputParams = processInputParams;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("variableId", getVariableId())
            .append("variableName", getVariableName())
            .append("variableNameEn", getVariableNameEn())
            .append("variableType", getVariableType())
            .append("description", getDescription())
            .append("sourceDataTable", getSourceDataTable())
            .append("dimensionTable", getDimensionTable())
            .append("createTime", getCreateTime())
            .append("modifyTime", getModifyTime())
            .toString();
    }
}
