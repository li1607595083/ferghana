package com.skyon.project.monitor.service;


import java.util.List;

public interface KeyindicatorsService {
    public List list();


}
