package com.skyon.project.system.controller;

import com.skyon.common.utils.poi.ExcelUtil;
import com.skyon.framework.aspectj.lang.annotation.Log;
import com.skyon.framework.aspectj.lang.enums.BusinessType;
import com.skyon.framework.web.controller.BaseController;
import com.skyon.framework.web.domain.AjaxResult;
import com.skyon.framework.web.page.TableDataInfo;
import com.skyon.project.system.domain.TVariableCenter;
import com.skyon.project.system.service.ITVariableCenterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 变量管理中心Controller
 * 
 * @author ruoyi
 * @date 2020-08-06
 */
@RestController
@RequestMapping("/variable/manager")
public class TVariableCenterController extends BaseController
{
    @Autowired
    private ITVariableCenterService tVariableCenterService;

    /**
     * 查询变量管理中心列表
     */
    @PreAuthorize("@ss.hasPermi('variable:manager:list')")
    @GetMapping("/list")
    public TableDataInfo list(TVariableCenter tVariableCenter)
    {
        startPage();
        List<TVariableCenter> list = tVariableCenterService.selectTVariableCenterList(tVariableCenter);
        return getDataTable(list);
    }

    /**
     * 导出变量管理中心列表
     */
    @PreAuthorize("@ss.hasPermi('variable:manager:export')")
    @Log(title = "变量管理中心", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(TVariableCenter tVariableCenter)
    {
        List<TVariableCenter> list = tVariableCenterService.selectTVariableCenterList(tVariableCenter);
        ExcelUtil<TVariableCenter> util = new ExcelUtil<TVariableCenter>(TVariableCenter.class);
        return util.exportExcel(list, "center");
    }

    /**
     * 获取变量管理中心详细信息
     */
    @PreAuthorize("@ss.hasPermi('variable:manager:query')")
    @GetMapping(value = "/{variableId}")
    public AjaxResult getInfo(@PathVariable("variableId") Long variableId)
    {
        return AjaxResult.success(tVariableCenterService.selectTVariableCenterById(variableId));
    }

    /**
     * 新增变量管理中心
     */
    @PreAuthorize("@ss.hasPermi('variable:manager:add')")
    @Log(title = "变量管理中心", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody TVariableCenter tVariableCenter)
    {
        return toAjax(tVariableCenterService.insertTVariableCenter(tVariableCenter));
    }

    /**
     * 修改变量管理中心
     */
    @PreAuthorize("@ss.hasPermi('system:center:edit')")
    @Log(title = "变量管理中心", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody TVariableCenter tVariableCenter)
    {
        return toAjax(tVariableCenterService.updateTVariableCenter(tVariableCenter));
    }

    /**
     * 删除变量管理中心
     */
    @PreAuthorize("@ss.hasPermi('system:center:remove')")
    @Log(title = "变量管理中心", businessType = BusinessType.DELETE)
	@DeleteMapping("/{variableIds}")
    public AjaxResult remove(@PathVariable Long[] variableIds)
    {
        return toAjax(tVariableCenterService.deleteTVariableCenterByIds(variableIds));
    }
}
