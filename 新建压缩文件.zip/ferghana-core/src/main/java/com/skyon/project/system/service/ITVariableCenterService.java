package com.skyon.project.system.service;

import com.skyon.project.system.domain.TVariableCenter;

import java.util.List;

/**
 * 变量管理中心Service接口
 * 
 * @author ruoyi
 * @date 2020-08-06
 */
public interface ITVariableCenterService 
{
    /**
     * 查询变量管理中心
     * 
     * @param variableId 变量管理中心ID
     * @return 变量管理中心
     */
    public TVariableCenter selectTVariableCenterById(Long variableId);

    /**
     * 查询变量管理中心列表
     * 
     * @param tVariableCenter 变量管理中心
     * @return 变量管理中心集合
     */
    public List<TVariableCenter> selectTVariableCenterList(TVariableCenter tVariableCenter);

    /**
     * 新增变量管理中心
     * 
     * @param tVariableCenter 变量管理中心
     * @return 结果
     */
    public int insertTVariableCenter(TVariableCenter tVariableCenter);

    /**
     * 修改变量管理中心
     * 
     * @param tVariableCenter 变量管理中心
     * @return 结果
     */
    public int updateTVariableCenter(TVariableCenter tVariableCenter);

    /**
     * 批量删除变量管理中心
     * 
     * @param variableIds 需要删除的变量管理中心ID
     * @return 结果
     */
    public int deleteTVariableCenterByIds(Long[] variableIds);

    /**
     * 删除变量管理中心信息
     * 
     * @param variableId 变量管理中心ID
     * @return 结果
     */
    public int deleteTVariableCenterById(Long variableId);
}
