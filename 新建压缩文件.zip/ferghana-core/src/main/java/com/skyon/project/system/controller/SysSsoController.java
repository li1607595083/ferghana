package com.skyon.project.system.controller;

import com.skyon.framework.security.service.SysSsoService;
import com.skyon.framework.web.domain.SsoResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.skyon.framework.web.domain.AjaxResult;

/**
 * 单点登录
 * @author zhouminfeng
 *
 */
@RestController
@RequestMapping("/sso")
public class SysSsoController {
	@Autowired
	private SysSsoService sysSsoService;

	
	/**
	 * 单点登录 获取token
	 * @param appId 调用者标识，门户系统标识为”portal”
	 * @param accessPwd 双方提前定义好一个密码
	 * @param userAccount 需要获取loginToken的用户账号
	 * @return
	 */
	@RequestMapping("/loginToken")
	public SsoResult getLoginToken(String appId, String accessPwd, String userAccount) {
//		UserDetails userDetails = userDetailsService.loadUserByUsername(userAccount);
//        PreAuthenticatedAuthenticationToken authentication =
//        		new PreAuthenticatedAuthenticationToken(userDetails,
//        				userDetails.getPassword(),
//        				userDetails.getAuthorities());
//
//      	//设置authentication中details
////		authentication.setDetails(new WebAuthenticationDetails(request));
//
//		//存放authentication到SecurityContextHolder
//		SecurityContextHolder.getContext().setAuthentication(authentication);
//
//		AjaxResult ajax = AjaxResult.success();
//        // 生成令牌
//		LoginUser loginUser = (LoginUser) authentication.getPrincipal();
//        String token = tokenService.createToken(loginUser);
//        ajax.put(Constants.TOKEN, token);
		return sysSsoService.getLoginToken(appId,accessPwd,userAccount);
	}
	
	@RequestMapping("/login")
	public AjaxResult login(String userAccount,String loginToken) {
		return sysSsoService.ssoLogin(userAccount,loginToken);
	}
}
