package com.skyon.project.system.service.impl;

import com.skyon.common.utils.DateUtils;
import com.skyon.project.system.domain.TVariableCenter;
import com.skyon.project.system.mapper.TVariableCenterMapper;
import com.skyon.project.system.service.ITVariableCenterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 变量管理中心Service业务层处理
 * 
 * @author ruoyi
 * @date 2020-08-06
 */
@Service
public class TVariableCenterServiceImpl implements ITVariableCenterService 
{
    @Autowired
    private TVariableCenterMapper tVariableCenterMapper;

    /**
     * 查询变量管理中心
     * 
     * @param variableId 变量管理中心ID
     * @return 变量管理中心
     */
    @Override
    public TVariableCenter selectTVariableCenterById(Long variableId)
    {
        return tVariableCenterMapper.selectTVariableCenterById(variableId);
    }

    /**
     * 查询变量管理中心列表
     * 
     * @param tVariableCenter 变量管理中心
     * @return 变量管理中心
     */
    @Override
    public List<TVariableCenter> selectTVariableCenterList(TVariableCenter tVariableCenter)
    {
        return tVariableCenterMapper.selectTVariableCenterList(tVariableCenter);
    }

    /**
     * 新增变量管理中心
     * 
     * @param tVariableCenter 变量管理中心
     * @return 结果
     */
    @Override
    public int insertTVariableCenter(TVariableCenter tVariableCenter)
    {
        tVariableCenter.setCreateTime(DateUtils.getNowDate());
        return tVariableCenterMapper.insertTVariableCenter(tVariableCenter);
    }

    /**
     * 修改变量管理中心
     * 
     * @param tVariableCenter 变量管理中心
     * @return 结果
     */
    @Override
    public int updateTVariableCenter(TVariableCenter tVariableCenter)
    {
        return tVariableCenterMapper.updateTVariableCenter(tVariableCenter);
    }

    /**
     * 批量删除变量管理中心
     * 
     * @param variableIds 需要删除的变量管理中心ID
     * @return 结果
     */
    @Override
    public int deleteTVariableCenterByIds(Long[] variableIds)
    {
        return tVariableCenterMapper.deleteTVariableCenterByIds(variableIds);
    }

    /**
     * 删除变量管理中心信息
     * 
     * @param variableId 变量管理中心ID
     * @return 结果
     */
    @Override
    public int deleteTVariableCenterById(Long variableId)
    {
        return tVariableCenterMapper.deleteTVariableCenterById(variableId);
    }
}
