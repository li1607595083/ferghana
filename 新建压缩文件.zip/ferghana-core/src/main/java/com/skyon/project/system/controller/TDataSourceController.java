package com.skyon.project.system.controller;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.skyon.common.utils.poi.ExcelUtil;
import com.skyon.framework.aspectj.lang.annotation.Log;
import com.skyon.framework.aspectj.lang.enums.BusinessType;
import com.skyon.framework.web.controller.BaseController;
import com.skyon.framework.web.domain.AjaxResult;
import com.skyon.framework.web.page.TableDataInfo;
import com.skyon.project.system.domain.TDataSource;
import com.skyon.project.system.service.ITDataSourceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 【请填写功能名称】Controller
 * 
 * @author ruoyi
 * @date 2020-05-21
 */
@RestController
@RequestMapping("/source/manage")
public class TDataSourceController extends BaseController
{
    @Autowired
    private ITDataSourceService tDataSourceService;

    /**
     * 查询【请填写功能名称】列表
     */
    @PreAuthorize("@ss.hasPermi('source:manage:list')")
    @GetMapping("/list")
    public TableDataInfo list(TDataSource tDataSource)
    {
        startPage();
        List<TDataSource> list = tDataSourceService.selectTDataSourceList(tDataSource);
        return getDataTable(list);
    }

    /**
     * 导出【请填写功能名称】列表
     */
    @PreAuthorize("@ss.hasPermi('source:manage:export')")
    @Log(title = "【请填写功能名称】", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(TDataSource tDataSource)
    {
        List<TDataSource> list = tDataSourceService.selectTDataSourceList(tDataSource);
        ExcelUtil<TDataSource> util = new ExcelUtil<TDataSource>(TDataSource.class);
        return util.exportExcel(list, "source");
    }

    /**
     * 获取【请填写功能名称】详细信息
     */
    @PreAuthorize("@ss.hasPermi('source:manage:query')")
    @GetMapping(value = "/{dataSourceId}")
    public AjaxResult getInfo(@PathVariable("dataSourceId") Long dataSourceId)
    {
        return AjaxResult.success(tDataSourceService.selectTDataSourceById(dataSourceId));
    }

    /**
     * 获取数据源表的schema字段
     */
    @RequestMapping(value = "/querySchema", method = RequestMethod.GET)
    @ResponseBody
    public TableDataInfo getInfoSchema(@RequestParam("dataSourceId") String dataSourceId)
    {
        List list = new ArrayList();
        String schemaDefine = tDataSourceService.selectTDataSourceById(new Long(dataSourceId)).getSchemaDefine();
        JSONArray parse = (JSONArray)JSONObject.parse(schemaDefine);
        for (int i = 0; i < parse.size(); i++) {
            Map o =(Map)parse.get(i);
            Map map = new HashMap();
            o.forEach((key, Value) -> {
                map.put("key",key);
                map.put("value",Value);
                list.add(map);
            });
        }
        return getDataTable(list);
    }

    /**
     * 新增【请填写功能名称】
     */
    @PreAuthorize("@ss.hasPermi('source:manage:add')")
    @Log(title = "【请填写功能名称】", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody TDataSource tDataSource)
    {
        return toAjax(tDataSourceService.insertTDataSource(tDataSource));
    }

    /**
     * 修改【请填写功能名称】
     */
    @PreAuthorize("@ss.hasPermi('source:manage:edit')")
    @Log(title = "【请填写功能名称】", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody TDataSource tDataSource)
    {
        return toAjax(tDataSourceService.updateTDataSource(tDataSource));
    }

    /**
     * 删除【请填写功能名称】
     */
    @PreAuthorize("@ss.hasPermi('source:manage:remove')")
    @Log(title = "【请填写功能名称】", businessType = BusinessType.DELETE)
    @DeleteMapping("/{dataSourceIds}")
    public AjaxResult remove(@PathVariable Long[] dataSourceIds)
    {
        return toAjax(tDataSourceService.deleteTDataSourceByIds(dataSourceIds));
    }
}
