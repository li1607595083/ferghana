package com.skyon.project.system.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.google.common.base.Strings;
import com.skyon.project.system.domain.TDataSource;
import com.skyon.project.system.mapper.TDataSourceMapper;
import com.skyon.project.system.service.ITDataSourceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 【请填写功能名称】Service业务层处理
 *
 * @author ruoyi
 * @date 2020-05-21
 */
@Service
public class TDataSourceServiceImpl implements ITDataSourceService {

    @Autowired
    private TDataSourceMapper tDataSourceMapper;

    /**
     * 查询【请填写功能名称】
     *
     * @param dataSourceId 【请填写功能名称】ID
     * @return 【请填写功能名称】
     */
    @Override
    public TDataSource selectTDataSourceById(Long dataSourceId) {

        TDataSource tDataSource = tDataSourceMapper.selectTDataSourceById(dataSourceId);
        String schemaDefine = tDataSource.getSchemaDefine();
        String schemaPrimaryKey = tDataSource.getSchemaPrimaryKey();
        if (!Strings.isNullOrEmpty(schemaDefine)) {
            List parse = (List) JSONObject.parse(schemaDefine);
            Object[] oejectArr = new Object[parse.size()];
            final int[] j = {0};
            for (int i = 0; i < parse.size(); i++) {
                Map o = (Map) parse.get(i);
                o.forEach((key, Value) -> {
                    HashMap<String, Object> hashMap = new HashMap<>();
                    hashMap.put("schemaDefine", key);
                    hashMap.put("dataBaseType", Value);
                    if (!Strings.isNullOrEmpty(schemaPrimaryKey)) {
                        if (schemaPrimaryKey.equals(key)) {
                            hashMap.put("primaryKey", key);
                        } else {
                            hashMap.put("primaryKey", "");
                        }
                    }
                    oejectArr[j[0]] = hashMap;
                    j[0] = j[0] + 1;
                });

            }
            tDataSource.setDynamicItem(oejectArr);
        }

        return tDataSource;
    }

    /**
     * 查询【请填写功能名称】列表
     *
     * @param tDataSource 【请填写功能名称】
     * @return 【请填写功能名称】
     */
    @Override
    public List<TDataSource> selectTDataSourceList(TDataSource tDataSource) {
        return tDataSourceMapper.selectTDataSourceList(tDataSource);
    }

    /**
     * 新增【请填写功能名称】
     *
     * @param tDataSource 【请填写功能名称】
     * @return 结果
     */
    @Override
    public int insertTDataSource(TDataSource tDataSource) {
        tranSchemaJson(tDataSource);
        return tDataSourceMapper.insertTDataSource(tDataSource);
    }

    public static void main(String[] args) {


    }

    /**
     * 修改【请填写功能名称】
     *
     * @param tDataSource 【请填写功能名称】
     * @return 结果
     */
    @Override
    public int updateTDataSource(TDataSource tDataSource) {
        tranSchemaJson(tDataSource);
        return tDataSourceMapper.updateTDataSource(tDataSource);
    }

    /**
     * 批量删除【请填写功能名称】
     *
     * @param dataSourceIds 需要删除的【请填写功能名称】ID
     * @return 结果
     */
    @Override
    public int deleteTDataSourceByIds(Long[] dataSourceIds) {
        return tDataSourceMapper.deleteTDataSourceByIds(dataSourceIds);
    }

    /**
     * 删除【请填写功能名称】信息
     *
     * @param dataSourceId 【请填写功能名称】ID
     * @return 结果
     */
    @Override
    public int deleteTDataSourceById(Long dataSourceId) {
        return tDataSourceMapper.deleteTDataSourceById(dataSourceId);
    }

    // 将数组转换为字段schema_defina的json格式
    private void tranSchemaJson(TDataSource tDataSource) {

        Object[] dynamicItem = tDataSource.getDynamicItem();
        List list = new ArrayList();
        if (dynamicItem != null && dynamicItem.length > 0) {
            for (int i = 0; i < dynamicItem.length; i++) {
                HashMap hashMap = new HashMap();
                HashMap o = (HashMap) dynamicItem[i];
                hashMap.put(o.get("schemaDefine"), o.get("dataBaseType"));
                list.add(hashMap);
            }
        }
        tDataSource.setSchemaDefine(JSONObject.toJSONString(list));
    }
}
