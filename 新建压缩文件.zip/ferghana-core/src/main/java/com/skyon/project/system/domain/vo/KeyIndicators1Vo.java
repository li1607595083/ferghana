package com.skyon.project.system.domain.vo;



// 信用卡重要指标数据vo
public class KeyIndicators1Vo {
    private String orgname;
    private String dkdr   ;
    private String dkjsr  ;
    private String dkjsy  ;
    private String dkjsn  ;
    private String bjxbjdr;
    private String bjxbjsr;
    private String bjxbjsy;
    private String bjxbjsn;
    private String xfxddr ;
    private String xfxdjsr;
    private String xfxdjsy;
    private String xfxdjsn;
    private String xfxd   ;
    private String fkldr  ;
    private String fkldy  ;
    private String fkldn  ;
    private String fklxzdr;
    private String fklxzsr;
    private String fklxjsy;
    private String fklxjsn;
    private String dkldr   ;
    private String dkljsr  ;
    private String dkljsy  ;
    private String dkljsn  ;
    private String xfkldr ;
    private String xfkljsr;
    private String xfkjsy ;
    private String xfkjsn ;
    private String srdr   ;
    private String srjsr  ;
    private String srjsy  ;
    private String srjsn  ;

    public String getOrgname() {
        return orgname;
    }

    public void setOrgname(String orgname) {
        this.orgname = orgname;
    }

    public String getDkdr() {
        return dkdr;
    }

    public void setDkdr(String dkdr) {
        this.dkdr = dkdr;
    }

    public String getDkjsr() {
        return dkjsr;
    }

    public void setDkjsr(String dkjsr) {
        this.dkjsr = dkjsr;
    }

    public String getDkjsy() {
        return dkjsy;
    }

    public void setDkjsy(String dkjsy) {
        this.dkjsy = dkjsy;
    }

    public String getDkjsn() {
        return dkjsn;
    }

    public void setDkjsn(String dkjsn) {
        this.dkjsn = dkjsn;
    }

    public String getBjxbjdr() {
        return bjxbjdr;
    }

    public void setBjxbjdr(String bjxbjdr) {
        this.bjxbjdr = bjxbjdr;
    }

    public String getBjxbjsr() {
        return bjxbjsr;
    }

    public void setBjxbjsr(String bjxbjsr) {
        this.bjxbjsr = bjxbjsr;
    }

    public String getBjxbjsy() {
        return bjxbjsy;
    }

    public void setBjxbjsy(String bjxbjsy) {
        this.bjxbjsy = bjxbjsy;
    }

    public String getBjxbjsn() {
        return bjxbjsn;
    }

    public void setBjxbjsn(String bjxbjsn) {
        this.bjxbjsn = bjxbjsn;
    }

    public String getXfxddr() {
        return xfxddr;
    }

    public void setXfxddr(String xfxddr) {
        this.xfxddr = xfxddr;
    }

    public String getXfxdjsr() {
        return xfxdjsr;
    }

    public void setXfxdjsr(String xfxdjsr) {
        this.xfxdjsr = xfxdjsr;
    }

    public String getXfxdjsy() {
        return xfxdjsy;
    }

    public void setXfxdjsy(String xfxdjsy) {
        this.xfxdjsy = xfxdjsy;
    }

    public String getXfxdjsn() {
        return xfxdjsn;
    }

    public void setXfxdjsn(String xfxdjsn) {
        this.xfxdjsn = xfxdjsn;
    }

    public String getXfxd() {
        return xfxd;
    }

    public void setXfxd(String xfxd) {
        this.xfxd = xfxd;
    }

    public String getFkldr() {
        return fkldr;
    }

    public void setFkldr(String fkldr) {
        this.fkldr = fkldr;
    }

    public String getFkldy() {
        return fkldy;
    }

    public void setFkldy(String fkldy) {
        this.fkldy = fkldy;
    }

    public String getFkldn() {
        return fkldn;
    }

    public void setFkldn(String fkldn) {
        this.fkldn = fkldn;
    }

    public String getFklxzdr() {
        return fklxzdr;
    }

    public void setFklxzdr(String fklxzdr) {
        this.fklxzdr = fklxzdr;
    }

    public String getFklxzsr() {
        return fklxzsr;
    }

    public void setFklxzsr(String fklxzsr) {
        this.fklxzsr = fklxzsr;
    }

    public String getFklxjsy() {
        return fklxjsy;
    }

    public void setFklxjsy(String fklxjsy) {
        this.fklxjsy = fklxjsy;
    }

    public String getFklxjsn() {
        return fklxjsn;
    }

    public void setFklxjsn(String fklxjsn) {
        this.fklxjsn = fklxjsn;
    }

    public String getDkldr() {
        return dkldr;
    }

    public void setDkldr(String dkldr) {
        this.dkldr = dkldr;
    }

    public String getDkljsr() {
        return dkljsr;
    }

    public void setDkljsr(String dkljsr) {
        this.dkljsr = dkljsr;
    }

    public String getDkljsy() {
        return dkljsy;
    }

    public void setDkljsy(String dkljsy) {
        this.dkljsy = dkljsy;
    }

    public String getDkljsn() {
        return dkljsn;
    }

    public void setDkljsn(String dkljsn) {
        this.dkljsn = dkljsn;
    }

    public String getXfkldr() {
        return xfkldr;
    }

    public void setXfkldr(String xfkldr) {
        this.xfkldr = xfkldr;
    }

    public String getXfkljsr() {
        return xfkljsr;
    }

    public void setXfkljsr(String xfkljsr) {
        this.xfkljsr = xfkljsr;
    }

    public String getXfkjsy() {
        return xfkjsy;
    }

    public void setXfkjsy(String xfkjsy) {
        this.xfkjsy = xfkjsy;
    }

    public String getXfkjsn() {
        return xfkjsn;
    }

    public void setXfkjsn(String xfkjsn) {
        this.xfkjsn = xfkjsn;
    }

    public String getSrdr() {
        return srdr;
    }

    public void setSrdr(String srdr) {
        this.srdr = srdr;
    }

    public String getSrjsr() {
        return srjsr;
    }

    public void setSrjsr(String srjsr) {
        this.srjsr = srjsr;
    }

    public String getSrjsy() {
        return srjsy;
    }

    public void setSrjsy(String srjsy) {
        this.srjsy = srjsy;
    }

    public String getSrjsn() {
        return srjsn;
    }

    public void setSrjsn(String srjsn) {
        this.srjsn = srjsn;
    }
}
