package com.skyon.project.system.controller;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.skyon.common.utils.poi.ExcelUtil;
import com.skyon.framework.aspectj.lang.annotation.Log;
import com.skyon.framework.aspectj.lang.enums.BusinessType;
import com.skyon.framework.web.controller.BaseController;
import com.skyon.framework.web.domain.AjaxResult;
import com.skyon.framework.web.page.TableDataInfo;
import com.skyon.project.system.domain.TDimensionTable;
import com.skyon.project.system.service.ITDimensionTableService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 数据维Controller
 * 
 * @author ruoyi
 * @date 2020-07-22
 */
@RestController
@RequestMapping("/system/Dimension")
public class TDimensionTableController extends BaseController
{
    @Autowired
    private ITDimensionTableService tDimensionTableService;

    /**
     * 查询数据维列表
     */
    @PreAuthorize("@ss.hasPermi('system:Dimension:list')")
    @GetMapping("/list")
    public TableDataInfo list(TDimensionTable tDimensionTable)
    {
        startPage();
        List<TDimensionTable> list = tDimensionTableService.selectTDimensionTableList(tDimensionTable);
        return getDataTable(list);
    }

    /**
     * 查询数据维列表
     */
    @PreAuthorize("@ss.hasPermi('system:Dimension:list')")
    @GetMapping("/typeQuery")
    public TableDataInfo typeQueryList()
    {
        List<Map> maps = tDimensionTableService.selectTDimensionTableListGroupByType();
        return getDataTable(maps);
    }

    /**
     * 根据连接器类型获取表名
     */
    @RequestMapping(value = "/tableNameQuery", method = RequestMethod.GET)
    @ResponseBody
    public TableDataInfo getTableNameInfo(@RequestParam("connType") String connType)
    {
        List<TDimensionTable> tDimensionTables = tDimensionTableService.selectTDimensionTableByConnType(connType);
        return getDataTable(tDimensionTables);
    }


    /**
     * 获取数据源表的schema字段
     */
    @RequestMapping(value = "/querySchema", method = RequestMethod.GET)
    @ResponseBody
    public TableDataInfo getInfoSchema(@RequestParam("dimensionId") String dimensionId)
    {
        List list = new ArrayList();
        String schemaDefine = tDimensionTableService.selectTDimensionTableById(new Long(dimensionId)).getSchemaDefine();
        JSONArray parse = (JSONArray) JSONObject.parse(schemaDefine);
        for (int i = 0; i < parse.size(); i++) {
            Map o =(Map)parse.get(i);
            o.forEach((key, Value) -> {
                list.add(key);
            });
        }
        return getDataTable(list);
    }


    /**
     * 导出数据维列表
     */
    @PreAuthorize("@ss.hasPermi('system:Dimension:export')")
    @Log(title = "数据维", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(TDimensionTable tDimensionTable)
    {
        List<TDimensionTable> list = tDimensionTableService.selectTDimensionTableList(tDimensionTable);
        ExcelUtil<TDimensionTable> util = new ExcelUtil<TDimensionTable>(TDimensionTable.class);
        return util.exportExcel(list, "table");
    }

    /**
     * 获取数据维详细信息
     */
    @PreAuthorize("@ss.hasPermi('system:Dimension:query')")
    @GetMapping(value = "/{dimensionId}")
    public AjaxResult getInfo(@PathVariable("dimensionId") Long dimensionId)
    {
        return AjaxResult.success(tDimensionTableService.selectTDimensionTableById(dimensionId));
    }

    /**
     * 新增数据维
     */
    @PreAuthorize("@ss.hasPermi('system:table:add')")
    @Log(title = "数据维", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody TDimensionTable tDimensionTable)
    {
        return toAjax(tDimensionTableService.insertTDimensionTable(tDimensionTable));
    }

    /**
     * 修改数据维
     */
    @PreAuthorize("@ss.hasPermi('system:Dimension:edit')")
    @Log(title = "数据维", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody TDimensionTable tDimensionTable)
    {
        return toAjax(tDimensionTableService.updateTDimensionTable(tDimensionTable));
    }

    /**
     * 删除数据维
     */
    @PreAuthorize("@ss.hasPermi('system:Dimension:remove')")
    @Log(title = "数据维", businessType = BusinessType.DELETE)
	@DeleteMapping("/{dimensionIds}")
    public AjaxResult remove(@PathVariable Long[] dimensionIds)
    {
        return toAjax(tDimensionTableService.deleteTDimensionTableByIds(dimensionIds));
    }
}
